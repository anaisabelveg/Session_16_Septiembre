package com.viewnext.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.models.Carrito;
import com.viewnext.services.ICarritoService;

@RestController
public class CarritoREST {
	
	@Autowired
	private ICarritoService service;
	
	// http://localhost:8003/crear/Miguel
	@PostMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario) {
		return service.crear(usuario);
	}
	
	// http://localhost:8003/agregar/id/3/cantidad/50/usuario/Miguel
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")
	public void agregarPedido(@PathVariable Long id, @PathVariable Integer cantidad, 
			@PathVariable String usuario) {
		service.agregarPedido(id, cantidad, usuario);
	}
    
	// http://localhost:8003/consultar/Miguel
	@GetMapping("/consultar/{usuario}")
	public Carrito consultar(@PathVariable String usuario) {
		return service.consultar(usuario);
	}
    
	// http://localhost:8003/sacar/id/3/usuario/Miguel
	@DeleteMapping("/sacar/id/{id}/usuario/{usuario}")
	public void eliminarPedido(@PathVariable Long id, @PathVariable String usuario) {
		service.eliminarPedido(id, usuario);
	}

}
