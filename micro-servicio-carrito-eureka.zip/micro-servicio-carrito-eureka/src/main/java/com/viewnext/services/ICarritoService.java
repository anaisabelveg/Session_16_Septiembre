package com.viewnext.services;

import com.viewnext.models.Carrito;

public interface ICarritoService {
	
	Carrito crear(String usuario);
    void agregarPedido(Long id, Integer cantidad, String usuario);
    Carrito consultar(String usuario);
    void eliminarPedido(Long id, String usuario);

}
